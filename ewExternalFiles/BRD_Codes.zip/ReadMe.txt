The files included here are related to 6 simulation studies discussed in our paper: Bayesian Nonparametric Variable Selection as an Exploratory Tool for Finding Genes that Matter. 

Simulation1.R - Simulation6.R: These are the codes for individual simulations
BDP: This code is code by Guindani et al. (2009)
BOPP: This code is written by Cao et al. (2009)
BRDZ: We wrote this code for our method based on z scores
BRDY: We wrote this code for our method based on the full data
dataP53.Rdata: this is a real dataset used for Simulation 3 - Simulation 6